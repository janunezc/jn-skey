# jn-skey

`jn-skey` is a Python tool that types the current datetime in the format `yyyy-mm-dd hh:mm:ss` when the `CTRL+D` combination is pressed, regardless of the application in focus.

I.e.: 2024-08-23 18:02:30

## Installation

You can install `jn-skey` via pip:

```bash
pip install jn-skey